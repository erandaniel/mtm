#include "Player.h"
#include "utilities.h"

#include <iostream>

using std::string;

Player::Player(std::string name, int maxHp, int force)
{
    m_name = name;

    if (maxHp <= 0)
    {
        m_maxHP = DEFUALT_HP;
    }
    else
    {
        m_maxHP = maxHp;
    }

    if (force < 0)
    {
        m_force = DEFUALT_FORCE;
    }
    else
    {
        m_force = force;
    }

    m_HP = m_maxHP;
    m_level = STARTING_LEVEL;
    m_coins = STARTING_COINS;
}

void Player::printInfo() const
{
    printPlayerInfo(m_name.c_str(), this->m_level,
                    this->m_force, this->m_HP, this->m_coins);
}

void Player::levelUp()
{
    if (m_level < MAX_LEVEL)
    {
        ++m_level;
    }
}

void Player::buff(int buffAmount)
{
    if (buffAmount <= 0)
    {
        return;
    }
    m_force += buffAmount;
}

void Player::heal(int hpToHeal)
{
    if (hpToHeal <= 0)
    {
        return;
    }
    if (m_HP + hpToHeal >= m_maxHP)
    {
        m_HP = m_maxHP;
    }
    else
    {
        m_HP += hpToHeal;
    }
}

void Player::damage(int damageTaken)
{
    if (damageTaken <= 0)
    {
        return;
    }
    if (m_HP - damageTaken < 0)
    {
        m_HP = 0;
    }
    else
    {
        m_HP -= damageTaken;
    }
}

void Player::addCoins(int coinsToAdd)
{
    if (coinsToAdd <= 0)
    {
        return;
    }
    m_coins += coinsToAdd;
}

bool Player::pay(int price)
{
    if (price <= 0)
    {
        return true;
    }
    if (m_coins >= price)
    {
        m_coins -= price;
        return true;
    }
    return false;
}

int Player::getAttackStrength() const
{
    return m_level + m_force;
}

bool Player::isKnockedOut() const
{
    if (m_HP <= 0)
    {
        return true;
    }
    return false;
}

int Player::getLevel() const
{
    return m_level;
}
