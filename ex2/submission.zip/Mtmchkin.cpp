
#include "Mtmchkin.h"
#include "Player.h"

#include <iostream>

using std::string;

Mtmchkin::Mtmchkin(const char *playerName, const Card *cardsArray, int numOfCards) : m_numOfCards(numOfCards), m_gameStatus(GameStatus::MidGame),
                                                                                     m_currentCardIndex(FIRST_CARD_INDEX), m_player(playerName)
{
    Card *temp = new Card[numOfCards];
    for (int i = 0; i < numOfCards; ++i)
    {
        temp[i] = cardsArray[i];
    }
    this->m_cardsArray = temp;
}

Mtmchkin::~Mtmchkin()
{
    delete[] m_cardsArray;
}

Card Mtmchkin::getCurrentCard()
{
    return m_cardsArray[m_currentCardIndex];
}

void Mtmchkin::playNextCard()
{
    getCurrentCard().printInfo();

    getCurrentCard().applyEncounter(m_player);

    m_player.printInfo();

    ++m_currentCardIndex;

    if ((int)m_currentCardIndex + 1 > m_numOfCards)
    {
        m_currentCardIndex = FIRST_CARD_INDEX;
    }

    if (m_player.getLevel() >= MAX_LEVEL)
    {
        m_gameStatus = GameStatus::Win;
    }
    if (m_player.isKnockedOut())
    {
        m_gameStatus = GameStatus::Loss;
    }
}

bool Mtmchkin::isOver() const
{

    if (m_gameStatus == GameStatus::MidGame)
    {
        return false;
    }
    else
    {
        return true;
    }
}

GameStatus Mtmchkin::getGameStatus() const
{
    return m_gameStatus;
}
