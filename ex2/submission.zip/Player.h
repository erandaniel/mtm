// 
// Created by Eran and Nick on 05/05/2022.
//
#ifndef EX2_PLAYER_H
#define EX2_PLAYER_H

#include <string>

const int MIN_LEVEL = 1;
const int MAX_LEVEL = 10;
const int STARTING_LEVEL = 1;
const int STARTING_COINS = 0;
const int DEFUALT_HP = 100;
const int DEFUALT_FORCE = 5;

class Player
{
private:
    std::string m_name;
    int m_level;
    int m_force;
    int m_maxHP;
    int m_HP;
    int m_coins;

public:
/*
* C'tor of  Player class.
*
* @param name - The name of the character.
* @param maxHp - The maximum amount of HealthPoints the character can have, default value is 100.
* @param force - The initial force of the character, default value is 5.
* @return 
*     A new instance of Player.
*/
    Player(std::string name, int maxHp = DEFUALT_HP, int force = DEFUALT_FORCE);

/*
* Copy C'tor of  Player class.
*
* @param player - The instance of the player that you want to copy.
* @return 
*     A new instance of Player.
*/
    Player(const Player &player) = default;

/*
* D'tor of  Player class.
*    Destroys instance of a Player
*/
    ~Player() = default;

/*
* Here we are explicitly telling the compiler to use the default method
*/
    Player& operator=(const Player& other) = default;

/*
* Prints the player's information.
*
* @return 
*      void
*/
    void printInfo() const;

/*
* Increases the character's level by 1, up to a maximum level of 10.
*
* @return 
*      void
*/
    void levelUp();

/*
* Returns the level of the character.
*
* @return 
*      The current level of the character
*/
    int getLevel() const;

/*
* Adds said amount of force to the character's force.
*
* @param buffAmount - The amount of force points to add to the character's force.
* @return 
*      void
*/
    void buff(int buffAmount);

/*
* Adds said amount of health to the character's health, cannot heal past the maxHP.
*
* @param hpToHeal - The amount of health points to add to the character's health.
* @return 
*      void
*/
    void heal(int hpToHeal);

/*
* Deducts said amount of health from the character's health, can't deduct past 0.
*
* @param damageTaken - The amount of health points to deduct from the character's health.
* @return 
*      void
*/
    void damage(int damageTaken);

/*
* Returns the status of the character(knocked out or not).
*
* @return 
*     'true' if the character has been knocked out, otherwise will return 'false'
*/
    bool isKnockedOut() const;

/*
* Adds said amount of coins to the character's coin purse.
*
* @param coinsToAdd - The amount of coins  to add to the character's coin purse.
* @return 
*      void
*/
    void addCoins(int coinsToAdd);
/*
* If the character can afford the transaction - deducts said amount of coins out of the
* character's purse, othwerise does nothing.
*
* @param price - The amount to deduct out of the character's coin purse.
* return
*     'true' if transaction is valid and the amount was deducted, otherwise 'false'
*/
    bool pay(int price);

/*
* Returns the attack strength of the character.
*
* @return 
*     The attack strength of the character
*/
    int getAttackStrength() const;
};

#endif // EX2_PLAYER_H
