//
// Created by Daniel_Meents on 07/04/2022.
//

#ifndef EX2_GAME_H
#define EX2_GAME_H
#include "Card.h"
#include "Player.h"

#include <iostream>

unsigned const int FIRST_CARD_INDEX = 0;
/*
 * GameStatus:
 * MidGame - The game is still active and the player continues to encounter cards.
 * Win - The player reached level 10.
 * Loss - The player's HP is 0.
 */
enum class GameStatus
{
    Win,
    Loss,
    MidGame
};

class Mtmchkin
{
public:
    /*
     * C'tor of the game:
     *
     * @param playerName - The name of the player.
     * @param cardsArray - A ptr to the cards deck.
     * @param numOfCards - Num of cards in the deck.
     * @result
     *      An instance of Mtmchkin
     */
    Mtmchkin(const char *playerName, const Card *cardsArray, int numOfCards);

    /*
     * D'tor of the game, free the pointer pointing to the cards array.
     *
     * @return
     *      void
     */
    ~Mtmchkin();

    /*
     * Play the next Card - according to the instruction in the exercise document
     *
     * @return
     *      void
     */
    void playNextCard();

    /*
     * get the next Card that will be played on the next call to playNextCard().
     *
     * @return
     *      void
     */
    Card getCurrentCard();

    /*
     *  Check if the game ended:
     *
     *  @return
     *          True if the game ended
     *          False otherwise
     */
    bool isOver() const;

    /*
     *  Get the status of the game:
     *
     *  @return
     *          GameStatus - the current status of the running game
     */
    GameStatus getGameStatus() const;

    /*
     * Here we are explicitly telling the compiler to use the default methods
     */
    Mtmchkin(const Mtmchkin &) = default;
    Mtmchkin &operator=(const Mtmchkin &other) = default;

private:
    int m_numOfCards;
    GameStatus m_gameStatus;
    unsigned int m_currentCardIndex;
    Player m_player;
    const Card *m_cardsArray;
};

#endif // EX2_GAME_H
